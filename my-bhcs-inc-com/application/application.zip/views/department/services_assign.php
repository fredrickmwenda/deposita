<div class="row">
    <div class="col-sm-12">
        <div  class="panel panel-default thumbnail">
            <?php
            if($this->permission->method('main_department','read')->access()  || $this->permission->method('main_department','update')->access() || $this->permission->method('main_department','delete')->access()){
            ?>
            <div class="panel-heading no-print">
                <div class="btn-group">
                    <a class="btn btn-primary" href="<?php echo base_url("patient_service/patient_services") ?>"> <i class="fa fa-list"></i> Services List</a>
                </div>
            </div>
            <?php } ?>


            <?php
            if($this->permission->method('add_main_department','create')->access()){
            ?>
            <div class="panel-body panel-form">
                <div class="row">
                    <div class="col-md-9 col-sm-12">

                        <?php echo form_open_multipart('#','class="form-inner"') ?>

                            <?php echo form_hidden('id',$department->id) ?>

                            <div class="form-group row">
                                <label for="name" class="col-xs-3 col-form-label">Service Name<i class="text-danger">*</i></label>
                                <div class="col-xs-9">
                                    <select class="form-control" name="">
                                      <option disabled value =''>Choose Service</option>
                                      <option value="pc" >PC<option>
                                      <option value="pc" >NHA<option>
                                      <option value="pc" >Nursing<option>
                                      <option value="pc" >PT<option>
                                      <option value="pc" >MRDD<option>
                                    </select>
                                </div>
                            </div>

                            <!--Radio-->
                            <div class="form-group row">
                                <label class="col-sm-3">Patient Name</label>
                                <div class="col-xs-9">
                                  <input class="form-control" type="text" name="" placeholder="Search Patient" value="">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-sm-3">Providers Name</label>
                                <div class="col-xs-9">
                                  <input class="form-control" type="text" name="" placeholder="Search Provider" value="">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-offset-3 col-sm-6">
                                    <div class="ui buttons">
                                        <button type="reset" class="ui button"><?php echo display('reset') ?></button>
                                        <div class="or"></div>
                                        <button class="ui positive button"><?php echo display('save') ?></button>
                                    </div>
                                </div>
                            </div>

                        <?php echo form_close() ?>

                    </div>
                </div>
            </div>
            <?php
            }
            else{
                ?>
                <div class="row">
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="panel-title">
                                      <h4><?php echo display('you_do_not_have_permission_to_access_please_contact_with_administrator');?>.</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
            }
             ?>

        </div>
    </div>

</div>
